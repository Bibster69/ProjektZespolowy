from django.contrib import admin
from .models import task, Profile


admin.site.register(task)
admin.site.register(Profile)
